<?php
include 'db_connect.php';
echo "Database connected successfully!";
$conn->close();
?>